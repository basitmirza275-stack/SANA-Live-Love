package com.example.data.repository

import com.example.data.model.GiftEvent
import com.example.data.model.GiftType
import com.example.data.model.GuestUser
import com.example.data.model.LiveComment
import com.example.data.model.LiveStream
import com.example.data.model.NotificationItem
import com.example.data.model.NotificationType
import com.example.data.model.PrivateMessage
import com.example.data.model.ReportItem
import com.example.data.model.ReportStatus
import com.example.data.model.User
import com.example.data.model.UserRole
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

class SanaRepository(private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default)) {

    // Current active logged in user
    private val _currentUser = MutableStateFlow(
        User(
            id = "user_me",
            username = "sana_angel",
            displayName = "Sana Angel ✨",
            bio = "Singing songs & spreading love 💕 Live Together, Smile Forever! 🌸",
            avatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80",
            followersCount = 15420,
            followingCount = 312,
            isVerified = true,
            role = UserRole.ADMIN // Default to Admin so user can test and showcase both regular & Admin panel
        )
    )
    val currentUser: StateFlow<User> = _currentUser.asStateFlow()

    // All creators / users database
    private val _allUsers = MutableStateFlow<List<User>>(listOf(
        _currentUser.value,
        User(
            id = "user_aria",
            username = "aria_melody",
            displayName = "Aria Melody 🎤",
            bio = "Singer & Voice Actor 🌸 Harmonizing your day with sweet songs!",
            avatarUrl = "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&auto=format&fit=crop&q=80",
            followersCount = 42800,
            followingCount = 145,
            isLive = true,
            isVerified = true
        ),
        User(
            id = "user_luna",
            username = "luna_star",
            displayName = "Luna Star 🌙",
            bio = "Cozy night talks, positive energy & tea time 🍵 Welcome to my safe space",
            avatarUrl = "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=400&auto=format&fit=crop&q=80",
            followersCount = 28900,
            followingCount = 89,
            isLive = true,
            isVerified = true
        ),
        User(
            id = "user_chloe",
            username = "chloe_dance",
            displayName = "Chloe K-Pop 💃",
            bio = "Dance instructor & choreography fun! Let's groove together! 💖",
            avatarUrl = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&auto=format&fit=crop&q=80",
            followersCount = 35100,
            followingCount = 210,
            isLive = true,
            isVerified = false
        ),
        User(
            id = "user_mochi",
            username = "mochi_bunny",
            displayName = "Mochi Bunny 🐰",
            bio = "Cute gamer bunny! Teddy bears & cozy chill streams 🎮🧸",
            avatarUrl = "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=400&auto=format&fit=crop&q=80",
            followersCount = 19300,
            followingCount = 130,
            isLive = true,
            isVerified = true
        ),
        User(
            id = "user_kenji",
            username = "kenji_guitar",
            displayName = "Kenji & Friends 🎸",
            bio = "Acoustic vibes, indie guitar chords and warm campfire memories.",
            avatarUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80",
            followersCount = 12400,
            followingCount = 95,
            isLive = true,
            isVerified = false
        )
    ))
    val allUsers: StateFlow<List<User>> = _allUsers.asStateFlow()

    // Followed user IDs
    private val _followedUserIds = MutableStateFlow<Set<String>>(setOf("user_aria", "user_luna"))
    val followedUserIds: StateFlow<Set<String>> = _followedUserIds.asStateFlow()

    // Blocked user IDs
    private val _blockedUserIds = MutableStateFlow<Set<String>>(emptySet())
    val blockedUserIds: StateFlow<Set<String>> = _blockedUserIds.asStateFlow()

    // Active Live Streams
    private val _liveStreams = MutableStateFlow<List<LiveStream>>(listOf(
        LiveStream(
            id = "stream_aria",
            hostUser = _allUsers.value.first { it.id == "user_aria" },
            title = "✨ Singing Disney & Pop Hits with Special Guests! 🎤",
            category = "Singing",
            coverUrl = "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=600&auto=format&fit=crop&q=80",
            viewerCount = 3420,
            likesCount = 18420,
            tags = listOf("Singing", "Music", "Multi-Guest", "Love"),
            guests = listOf(
                GuestUser(
                    id = "guest_1",
                    username = "rose_duet",
                    displayName = "Rose Duet 🌸",
                    avatarUrl = "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=300&auto=format&fit=crop&q=80",
                    isMuted = false,
                    isCameraOn = true
                ),
                GuestUser(
                    id = "guest_2",
                    username = "leo_chords",
                    displayName = "Leo Keys 🎹",
                    avatarUrl = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&auto=format&fit=crop&q=80",
                    isMuted = false,
                    isCameraOn = true
                )
            )
        ),
        LiveStream(
            id = "stream_luna",
            hostUser = _allUsers.value.first { it.id == "user_luna" },
            title = "🌙 Late Night Cozy Chit-Chat & Teddy Hugs 🧸",
            category = "Chit-Chat",
            coverUrl = "https://images.unsplash.com/photo-1518495973542-4542c06a5843?w=600&auto=format&fit=crop&q=80",
            viewerCount = 1890,
            likesCount = 9850,
            tags = listOf("Chit-Chat", "Relax", "TeddySquad"),
            guests = listOf(
                GuestUser(
                    id = "guest_3",
                    username = "starlight_maya",
                    displayName = "Maya 🌟",
                    avatarUrl = "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=300&auto=format&fit=crop&q=80"
                )
            )
        ),
        LiveStream(
            id = "stream_chloe",
            hostUser = _allUsers.value.first { it.id == "user_chloe" },
            title = "💃 K-Pop Dance Challenge & Free Gift Party! 💖",
            category = "Dancing",
            coverUrl = "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=600&auto=format&fit=crop&q=80",
            viewerCount = 2750,
            likesCount = 14200,
            tags = listOf("Dancing", "K-Pop", "FreeGifts")
        ),
        LiveStream(
            id = "stream_mochi",
            hostUser = _allUsers.value.first { it.id == "user_mochi" },
            title = "🐰 Animal Crossing Island Tour + Guest Stage! 🎮",
            category = "Gaming",
            coverUrl = "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=600&auto=format&fit=crop&q=80",
            viewerCount = 1240,
            likesCount = 6320,
            tags = listOf("Gaming", "Cute", "BunnyLover")
        ),
        LiveStream(
            id = "stream_kenji",
            hostUser = _allUsers.value.first { it.id == "user_kenji" },
            title = "🎸 Acoustic Guitar Jam Session & Song Requests",
            category = "Music",
            coverUrl = "https://images.unsplash.com/photo-1465847899084-d164df4dedc6?w=600&auto=format&fit=crop&q=80",
            viewerCount = 860,
            likesCount = 4150,
            tags = listOf("Music", "Guitar", "Chill")
        )
    ))
    val liveStreams: StateFlow<List<LiveStream>> = _liveStreams.asStateFlow()

    // Comments map per stream
    private val _streamComments = MutableStateFlow<Map<String, List<LiveComment>>>(
        mapOf(
            "stream_aria" to listOf(
                LiveComment(
                    id = "c1",
                    streamId = "stream_aria",
                    user = _allUsers.value.first { it.id == "user_luna" },
                    message = "Your voice is like sweet honey today! 🌸💕"
                ),
                LiveComment(
                    id = "c2",
                    streamId = "stream_aria",
                    user = _allUsers.value.first { it.id == "user_mochi" },
                    message = "Can we do the trio duet next? Excited! 🎤✨"
                ),
                LiveComment(
                    id = "c3",
                    streamId = "stream_aria",
                    user = _currentUser.value,
                    message = "Sending free roses to everyone! 🌹🌹🌹",
                    isGiftMessage = true,
                    giftType = GiftType.ROSE
                )
            ),
            "stream_luna" to listOf(
                LiveComment(
                    id = "c4",
                    streamId = "stream_luna",
                    user = _allUsers.value.first { it.id == "user_kenji" },
                    message = "Such peaceful night vibes 🌙💫"
                )
            )
        )
    )
    val streamComments: StateFlow<Map<String, List<LiveComment>>> = _streamComments.asStateFlow()

    // Gift Stats counter (Tracking free gifts sent)
    private val _giftStats = MutableStateFlow<Map<GiftType, Int>>(
        GiftType.values().associateWith { (120..850).random() }
    )
    val giftStats: StateFlow<Map<GiftType, Int>> = _giftStats.asStateFlow()

    // Private messages map: otherUserId -> List<PrivateMessage>
    private val _privateMessages = MutableStateFlow<Map<String, List<PrivateMessage>>>(
        mapOf(
            "user_aria" to listOf(
                PrivateMessage(
                    id = "m1",
                    senderId = "user_aria",
                    receiverId = "user_me",
                    message = "Hey Sana Angel! Thank you so much for the free bouquet gift on stream today! 💐✨",
                    timestamp = System.currentTimeMillis() - 3600000 * 2
                ),
                PrivateMessage(
                    id = "m2",
                    senderId = "user_me",
                    receiverId = "user_aria",
                    message = "You sang so beautifully! Looking forward to joining your guest stage again soon! 💕",
                    timestamp = System.currentTimeMillis() - 3600000 * 1
                )
            ),
            "user_luna" to listOf(
                PrivateMessage(
                    id = "m3",
                    senderId = "user_luna",
                    receiverId = "user_me",
                    message = "Sweet dreams my friend! Don't forget our cozy chit-chat live stream tomorrow 🌙🧸",
                    timestamp = System.currentTimeMillis() - 7200000
                )
            )
        )
    )
    val privateMessages: StateFlow<Map<String, List<PrivateMessage>>> = _privateMessages.asStateFlow()

    // Notifications list
    private val _notifications = MutableStateFlow<List<NotificationItem>>(listOf(
        NotificationItem(
            id = "n1",
            type = NotificationType.GIFT,
            title = "Free Gift Received! 🎁",
            subtitle = "Aria Melody sent you a Diamond 💎 and Love Bouquet 💐 on SANA!",
            timestamp = System.currentTimeMillis() - 1800000
        ),
        NotificationItem(
            id = "n2",
            type = NotificationType.LIVE,
            title = "Multi-Guest Room Started! 🎤",
            subtitle = "Aria Melody & 2 guests are live now: Singing Disney & Pop Hits!",
            timestamp = System.currentTimeMillis() - 3600000
        ),
        NotificationItem(
            id = "n3",
            type = NotificationType.FOLLOW,
            title = "New Follower 💖",
            subtitle = "Mochi Bunny started following you!",
            timestamp = System.currentTimeMillis() - 7200000
        ),
        NotificationItem(
            id = "n4",
            type = NotificationType.SYSTEM,
            title = "Welcome to SANA – Live & Love! 🌸",
            subtitle = "All virtual gifts are 100% free! Live Together, Smile Forever.",
            timestamp = System.currentTimeMillis() - 86400000
        )
    ))
    val notifications: StateFlow<List<NotificationItem>> = _notifications.asStateFlow()

    // Safety Reports List
    private val _reports = MutableStateFlow<List<ReportItem>>(listOf(
        ReportItem(
            id = "rep_101",
            reporterId = "user_aria",
            reportedUserId = "user_kenji",
            reportedUserName = "Kenji & Friends",
            reportedStreamId = "stream_kenji",
            reason = "Spam / Inappropriate chat comments",
            details = "Repeated advertising links in chat during broadcast.",
            status = ReportStatus.PENDING
        )
    ))
    val reports: StateFlow<List<ReportItem>> = _reports.asStateFlow()

    // User Profile Actions
    fun updateProfile(displayName: String, username: String, bio: String, avatarUrl: String) {
        _currentUser.update {
            it.copy(
                displayName = displayName.ifBlank { it.displayName },
                username = username.ifBlank { it.username },
                bio = bio.ifBlank { it.bio },
                avatarUrl = avatarUrl.ifBlank { it.avatarUrl }
            )
        }
    }

    fun toggleRole(role: UserRole) {
        _currentUser.update { it.copy(role = role) }
    }

    fun isFollowing(userId: String): Boolean = _followedUserIds.value.contains(userId)

    fun toggleFollow(userId: String) {
        _followedUserIds.update { set ->
            if (set.contains(userId)) {
                set - userId
            } else {
                // Add notification
                val targetUser = _allUsers.value.find { it.id == userId }
                val targetName = targetUser?.displayName ?: "Creator"
                _notifications.update { list ->
                    listOf(
                        NotificationItem(
                            id = UUID.randomUUID().toString(),
                            type = NotificationType.FOLLOW,
                            title = "Following $targetName 💕",
                            subtitle = "You will now receive alerts when they go live!"
                        )
                    ) + list
                }
                set + userId
            }
        }
    }

    fun blockUser(userId: String) {
        _blockedUserIds.update { it + userId }
    }

    fun unblockUser(userId: String) {
        _blockedUserIds.update { it - userId }
    }

    fun isUserBlocked(userId: String): Boolean = _blockedUserIds.value.contains(userId)

    // Stream Comments & Free Gifts
    fun sendComment(streamId: String, text: String) {
        if (text.isBlank()) return
        val comment = LiveComment(
            id = UUID.randomUUID().toString(),
            streamId = streamId,
            user = _currentUser.value,
            message = text.trim()
        )
        _streamComments.update { map ->
            val list = map[streamId] ?: emptyList()
            map + (streamId to (list + comment))
        }
    }

    fun sendFreeGift(streamId: String, giftType: GiftType): GiftEvent {
        val event = GiftEvent(
            id = UUID.randomUUID().toString(),
            sender = _currentUser.value,
            giftType = giftType,
            count = 1
        )

        // Increment gift stats
        _giftStats.update { stats ->
            val current = stats[giftType] ?: 0
            stats + (giftType to (current + 1))
        }

        // Add special gift celebration comment
        val giftComment = LiveComment(
            id = UUID.randomUUID().toString(),
            streamId = streamId,
            user = _currentUser.value,
            message = "Sent free ${giftType.giftName} ${giftType.emoji}! ${giftType.slogan}",
            isGiftMessage = true,
            giftType = giftType
        )
        _streamComments.update { map ->
            val list = map[streamId] ?: emptyList()
            map + (streamId to (list + giftComment))
        }

        // Increase stream likes & add to recent gifts
        _liveStreams.update { streams ->
            streams.map { s ->
                if (s.id == streamId) {
                    s.copy(
                        likesCount = s.likesCount + 25,
                        recentGifts = (listOf(event) + s.recentGifts).take(5)
                    )
                } else s
            }
        }

        return event
    }

    fun tapHeart(streamId: String) {
        _liveStreams.update { streams ->
            streams.map { s ->
                if (s.id == streamId) s.copy(likesCount = s.likesCount + 1) else s
            }
        }
    }

    // Multi-Guest actions
    fun joinAsGuest(streamId: String) {
        val myUser = _currentUser.value
        val newGuest = GuestUser(
            id = myUser.id,
            username = myUser.username,
            displayName = myUser.displayName,
            avatarUrl = myUser.avatarUrl,
            isMuted = false,
            isCameraOn = true
        )
        _liveStreams.update { streams ->
            streams.map { s ->
                if (s.id == streamId && s.guests.none { it.id == myUser.id }) {
                    s.copy(guests = s.guests + newGuest)
                } else s
            }
        }
        sendComment(streamId, "Joined the guest stage! Hello everyone! 💕🎤")
    }

    fun leaveGuestStage(streamId: String) {
        val myId = _currentUser.value.id
        _liveStreams.update { streams ->
            streams.map { s ->
                if (s.id == streamId) {
                    s.copy(guests = s.guests.filterNot { it.id == myId })
                } else s
            }
        }
    }

    fun removeGuestByHost(streamId: String, guestId: String) {
        _liveStreams.update { streams ->
            streams.map { s ->
                if (s.id == streamId) {
                    s.copy(guests = s.guests.filterNot { it.id == guestId })
                } else s
            }
        }
    }

    fun toggleCommentsEnabled(streamId: String) {
        _liveStreams.update { streams ->
            streams.map { s ->
                if (s.id == streamId) s.copy(isCommentsEnabled = !s.isCommentsEnabled) else s
            }
        }
    }

    // Start user's own broadcast
    fun startBroadcast(title: String, category: String, allowGuests: Boolean): LiveStream {
        val streamId = "stream_user_" + System.currentTimeMillis()
        val newStream = LiveStream(
            id = streamId,
            hostUser = _currentUser.value,
            title = title.ifBlank { "🌸 Live with Sana Angel! Come say hi!" },
            category = category.ifBlank { "Chit-Chat" },
            coverUrl = _currentUser.value.avatarUrl,
            viewerCount = 1,
            likesCount = 0,
            tags = listOf(category, "SANA", "Love"),
            isLive = true
        )
        _liveStreams.update { listOf(newStream) + it }

        // Start simulated viewer growth and incoming friendly comments
        scope.launch {
            delay(2500)
            _liveStreams.update { list ->
                list.map { if (it.id == streamId) it.copy(viewerCount = it.viewerCount + 14, likesCount = it.likesCount + 30) else it }
            }
            sendComment(streamId, "Welcome to the live stream! Live Together, Smile Forever! 💖")
            delay(3000)
            val friendlyGuest = _allUsers.value.first { it.id == "user_luna" }
            _streamComments.update { map ->
                val list = map[streamId] ?: emptyList()
                map + (streamId to (list + LiveComment(
                    id = UUID.randomUUID().toString(),
                    streamId = streamId,
                    user = friendlyGuest,
                    message = "Yay you're live! Sending love! 🌸✨",
                    isGiftMessage = true,
                    giftType = GiftType.HEART
                )))
            }
            if (allowGuests) {
                delay(4000)
                // Add friendly guest to stage automatically to demo multi-guest
                val guestObj = GuestUser(
                    id = friendlyGuest.id,
                    username = friendlyGuest.username,
                    displayName = friendlyGuest.displayName,
                    avatarUrl = friendlyGuest.avatarUrl
                )
                _liveStreams.update { list ->
                    list.map { if (it.id == streamId && it.guests.isEmpty()) it.copy(guests = listOf(guestObj), viewerCount = it.viewerCount + 85) else it }
                }
            }
        }

        return newStream
    }

    fun endStream(streamId: String) {
        _liveStreams.update { streams ->
            streams.filterNot { it.id == streamId }
        }
    }

    // Private Messaging
    fun sendPrivateMessage(receiverId: String, text: String) {
        if (text.isBlank()) return
        val msg = PrivateMessage(
            id = UUID.randomUUID().toString(),
            senderId = _currentUser.value.id,
            receiverId = receiverId,
            message = text.trim()
        )
        _privateMessages.update { map ->
            val list = map[receiverId] ?: emptyList()
            map + (receiverId to (list + msg))
        }

        // Simulate friendly reply after a short delay
        scope.launch {
            delay(2000)
            val replyText = when (receiverId) {
                "user_aria" -> "Aww that is so sweet of you! Sending you hugs and positive tunes! 🎶💖"
                "user_luna" -> "Thank you! Remember to smile today, you're amazing! 🌙✨"
                "user_chloe" -> "Let's dance together on the next multi-guest live! 💃"
                else -> "Got your message! Love you! 💕"
            }
            val replyMsg = PrivateMessage(
                id = UUID.randomUUID().toString(),
                senderId = receiverId,
                receiverId = _currentUser.value.id,
                message = replyText
            )
            _privateMessages.update { map ->
                val list = map[receiverId] ?: emptyList()
                map + (receiverId to (list + replyMsg))
            }
        }
    }

    // Safety & Reporting
    fun submitReport(reportedUserId: String, reportedUserName: String, streamId: String?, reason: String, details: String) {
        val report = ReportItem(
            id = "rep_" + System.currentTimeMillis(),
            reporterId = _currentUser.value.id,
            reportedUserId = reportedUserId,
            reportedUserName = reportedUserName,
            reportedStreamId = streamId,
            reason = reason,
            details = details,
            status = ReportStatus.PENDING
        )
        _reports.update { listOf(report) + it }
    }

    fun resolveReport(reportId: String, suspendUser: Boolean) {
        val rep = _reports.value.find { it.id == reportId }
        if (suspendUser && rep != null) {
            suspendAccount(rep.reportedUserId)
        }
        _reports.update { list ->
            list.map { if (it.id == reportId) it.copy(status = ReportStatus.RESOLVED) else it }
        }
    }

    fun dismissReport(reportId: String) {
        _reports.update { list ->
            list.map { if (it.id == reportId) it.copy(status = ReportStatus.DISMISSED) else it }
        }
    }

    fun suspendAccount(userId: String) {
        _allUsers.update { users ->
            users.map { if (it.id == userId) it.copy(isBlocked = true) else it }
        }
        // Also remove any active streams by that user
        _liveStreams.update { streams ->
            streams.filterNot { it.hostUser.id == userId }
        }
    }

    fun unbanAccount(userId: String) {
        _allUsers.update { users ->
            users.map { if (it.id == userId) it.copy(isBlocked = false) else it }
        }
    }
}
