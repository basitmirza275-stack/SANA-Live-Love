package com.example.data.model

enum class UserRole {
    USER,
    ADMIN,
    MODERATOR
}

data class User(
    val id: String,
    val username: String,
    val displayName: String,
    val bio: String,
    val avatarUrl: String,
    val followersCount: Int = 120,
    val followingCount: Int = 45,
    val isLive: Boolean = false,
    val isOnline: Boolean = true,
    val isVerified: Boolean = false,
    val role: UserRole = UserRole.USER,
    val isBlocked: Boolean = false,
    val isMuted: Boolean = false
)

enum class GiftType(
    val giftName: String,
    val emoji: String,
    val slogan: String,
    val accentColorHex: Long,
    val description: String,
    val displayedValueLabel: String,
    val isHugeCelebration: Boolean = false
) {
    ROSE(
        giftName = "Rose",
        emoji = "🌹",
        slogan = "Fragrant Bloom of Love",
        accentColorHex = 0xFFFF2E7E,
        description = "A delicate crimson rose showing sweet affection",
        displayedValueLabel = "FREE"
    ),
    HEART(
        giftName = "Heart",
        emoji = "💖",
        slogan = "Pure Love Explosion",
        accentColorHex = 0xFFFF1744,
        description = "A radiant pulsating heart full of warmth",
        displayedValueLabel = "FREE"
    ),
    TEDDY_BEAR(
        giftName = "Teddy Bear",
        emoji = "🧸",
        slogan = "Cuddly Warm Hugs",
        accentColorHex = 0xFFFF9800,
        description = "Super fluffy teddy bear to bring happy smiles",
        displayedValueLabel = "FREE"
    ),
    LOVE_BOUQUET(
        giftName = "Flower Bouquet",
        emoji = "💐",
        slogan = "Grand Romance",
        accentColorHex = 0xFFE91E63,
        description = "Spectacular bundle of enchanted blossoming flowers",
        displayedValueLabel = "FREE"
    ),
    BUTTERFLY(
        giftName = "Butterfly",
        emoji = "🦋",
        slogan = "Magical Wing Flutter",
        accentColorHex = 0xFF00E5FF,
        description = "Glow butterfly dancing with fairy dust",
        displayedValueLabel = "FREE"
    ),
    DIAMOND(
        giftName = "Diamond",
        emoji = "💎",
        slogan = "Eternal Brilliance",
        accentColorHex = 0xFF64B5F6,
        description = "Sparkling crystalline gem that dazzles the room",
        displayedValueLabel = "FREE"
    ),
    LUXURY_CAR(
        giftName = "Luxury Sports Car",
        emoji = "🏎️",
        slogan = "Speed of Passion",
        accentColorHex = 0xFFFF1744,
        description = "Roaring supercar with heart exhausts (Visual 200,000 Value)",
        displayedValueLabel = "200,000 Value (FREE)",
        isHugeCelebration = true
    ),
    PRIVATE_JET(
        giftName = "Private Jet",
        emoji = "✈️",
        slogan = "Soaring Across the Sky",
        accentColorHex = 0xFF2979FF,
        description = "Supersonic VIP jet soaring across live stage",
        displayedValueLabel = "1,500,000 Value (FREE)",
        isHugeCelebration = true
    ),
    GOLDEN_CROWN(
        giftName = "Golden Crown",
        emoji = "👑",
        slogan = "Royal SANA Majesty",
        accentColorHex = 0xFFFFD700,
        description = "Dazzling 24K coronation crown for the stream queen or king",
        displayedValueLabel = "500,000 Value (FREE)",
        isHugeCelebration = true
    ),
    CASTLE(
        giftName = "Enchanted Castle",
        emoji = "🏰",
        slogan = "Fairy Tale Kingdom",
        accentColorHex = 0xFF9C27B0,
        description = "Majestic glowing castle with fireworks and royal towers",
        displayedValueLabel = "10,000,000 Value (FREE)",
        isHugeCelebration = true
    ),
    FIREWORKS(
        giftName = "Grand Fireworks",
        emoji = "🎆",
        slogan = "Spectacular Light Show",
        accentColorHex = 0xFFFF4081,
        description = "Dazzling skyburst fireworks illuminating the live room",
        displayedValueLabel = "50,000 Value (FREE)"
    ),
    BIRTHDAY_CAKE(
        giftName = "Birthday Cake",
        emoji = "🎂",
        slogan = "Sweet Celebration",
        accentColorHex = 0xFFFF80AB,
        description = "Delicious strawberry cake with sparkling celebration candles",
        displayedValueLabel = "FREE"
    ),
    MOON_STARS(
        giftName = "Moon & Stars",
        emoji = "🌙",
        slogan = "Celestial Enchantment",
        accentColorHex = 0xFF8C3BFF,
        description = "Shining crescent moon and twinkling starlight",
        displayedValueLabel = "FREE"
    ),
    GIANT_LOVE_GALAXY(
        giftName = "Giant Love Galaxy",
        emoji = "🌌",
        slogan = "Cosmic Swirl of Eternal Love",
        accentColorHex = 0xFF7C4DFF,
        description = "Enormous cosmic love nebula swirling with galactic stars",
        displayedValueLabel = "50,000,000 Value (FREE)",
        isHugeCelebration = true
    ),
    ROYAL_INFINITY(
        giftName = "Royal SANA Infinity",
        emoji = "🌠",
        slogan = "Ultimate 80,000,000 Celebration",
        accentColorHex = 0xFFFFB300,
        description = "Legendary mega gift! Visual 80,000,000 coins value - completely free to send!",
        displayedValueLabel = "80,000,000 Value (FREE)",
        isHugeCelebration = true
    );

    val isFree: Boolean = true
    val purchaseCostCoins: Int = 0
}

data class GuestUser(
    val id: String,
    val username: String,
    val displayName: String,
    val avatarUrl: String,
    val isMuted: Boolean = false,
    val isCameraOn: Boolean = true,
    val joinedAt: Long = System.currentTimeMillis()
)

data class GiftEvent(
    val id: String,
    val sender: User,
    val giftType: GiftType,
    val count: Int = 1,
    val timestamp: Long = System.currentTimeMillis()
)

data class LiveComment(
    val id: String,
    val streamId: String,
    val user: User,
    val message: String,
    val isGiftMessage: Boolean = false,
    val giftType: GiftType? = null,
    val timestamp: Long = System.currentTimeMillis()
)

data class LiveStream(
    val id: String,
    val hostUser: User,
    val title: String,
    val category: String,
    val coverUrl: String,
    val viewerCount: Int,
    val likesCount: Int,
    val guests: List<GuestUser> = emptyList(),
    val isLive: Boolean = true,
    val startedAt: Long = System.currentTimeMillis(),
    val tags: List<String> = emptyList(),
    val isCommentsEnabled: Boolean = true,
    val isMicrophoneMuted: Boolean = false,
    val cameraFacing: String = "front",
    val recentGifts: List<GiftEvent> = emptyList()
)

data class PrivateMessage(
    val id: String,
    val senderId: String,
    val receiverId: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = true
)

enum class NotificationType {
    GIFT,
    FOLLOW,
    LIVE,
    SYSTEM
}

data class NotificationItem(
    val id: String,
    val type: NotificationType,
    val title: String,
    val subtitle: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)

enum class ReportStatus {
    PENDING,
    RESOLVED,
    DISMISSED
}

data class ReportItem(
    val id: String,
    val reporterId: String,
    val reportedUserId: String,
    val reportedUserName: String,
    val reportedStreamId: String?,
    val reason: String,
    val details: String,
    val status: ReportStatus = ReportStatus.PENDING,
    val timestamp: Long = System.currentTimeMillis()
)
