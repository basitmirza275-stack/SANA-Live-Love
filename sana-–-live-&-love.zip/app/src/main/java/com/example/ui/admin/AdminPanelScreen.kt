package com.example.ui.admin

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Report
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.GiftType
import com.example.data.model.LiveStream
import com.example.data.model.ReportItem
import com.example.data.model.ReportStatus
import com.example.data.model.User
import com.example.data.repository.SanaRepository
import com.example.ui.components.SanaLiveBadge
import com.example.ui.theme.SanaGoldAccent
import com.example.ui.theme.SanaGreenOnline
import com.example.ui.theme.SanaPinkPrimary
import com.example.ui.theme.SanaPinkSoft
import com.example.ui.theme.SanaPurpleDark
import com.example.ui.theme.SanaPurpleSecondary
import com.example.ui.theme.SanaPurpleSoft
import com.example.ui.theme.SanaRedLive

@Composable
fun AdminPanelScreen(
    repository: SanaRepository,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    var selectedTab by remember { mutableIntStateOf(0) }
    val reports by repository.reports.collectAsState()
    val liveStreams by repository.liveStreams.collectAsState()
    val allUsers by repository.allUsers.collectAsState()
    val giftStats by repository.giftStats.collectAsState()

    val pendingReportsCount = reports.count { it.status == ReportStatus.PENDING }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF9F4FA))
            .statusBarsPadding()
    ) {
        // Top Admin Bar
        Surface(
            color = Color(0xFF1E112E),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                    imageVector = Icons.Default.AdminPanelSettings,
                    contentDescription = null,
                    tint = SanaGoldAccent,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "SANA Admin & Moderation",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                    Text(
                        text = "Safety Management & Live Operations",
                        style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFFD4C0E2))
                    )
                }
            }
        }

        // Tabs
        val tabs = listOf(
            "Reports ($pendingReportsCount)",
            "Live Streams (${liveStreams.size})",
            "Manage Users (${allUsers.size})",
            "Free Gifts"
        )

        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color.White,
            contentColor = SanaPinkPrimary,
            edgePadding = 16.dp,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = SanaPinkPrimary
                )
            }
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = {
                        Text(
                            text = title,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                )
            }
        }

        // Tab Content
        Box(modifier = Modifier.weight(1f)) {
            when (selectedTab) {
                0 -> AdminReportsTab(
                    reports = reports,
                    onResolve = { repId, ban -> repository.resolveReport(repId, ban) },
                    onDismiss = { repId -> repository.dismissReport(repId) }
                )
                1 -> AdminStreamsTab(
                    streams = liveStreams,
                    onEndStream = { streamId -> repository.endStream(streamId) }
                )
                2 -> AdminUsersTab(
                    users = allUsers,
                    onToggleSuspend = { userId, isBlocked ->
                        if (isBlocked) repository.unbanAccount(userId) else repository.suspendAccount(userId)
                    }
                )
                3 -> AdminGiftsTab(
                    giftStats = giftStats
                )
            }
        }
    }
}

@Composable
private fun AdminReportsTab(
    reports: List<ReportItem>,
    onResolve: (String, Boolean) -> Unit,
    onDismiss: (String) -> Unit
) {
    if (reports.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text("No reports! SANA community is safe and happy 🌸")
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(reports) { report ->
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Reported: ${report.reportedUserName}",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (report.status == ReportStatus.PENDING) Color(0xFFFFEBEE) else Color(0xFFE8F5E9)
                            ) {
                                Text(
                                    text = report.status.name,
                                    color = if (report.status == ReportStatus.PENDING) SanaRedLive else SanaGreenOnline,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Reason: ${report.reason}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = SanaPinkPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                        if (report.details.isNotBlank()) {
                            Text(
                                text = "Details: ${report.details}",
                                style = MaterialTheme.typography.bodySmall.copy(color = Color.DarkGray)
                            )
                        }

                        if (report.status == ReportStatus.PENDING) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { onResolve(report.id, true) },
                                    colors = ButtonDefaults.buttonColors(containerColor = SanaRedLive),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Suspend User", fontSize = 12.sp, color = Color.White)
                                }
                                Button(
                                    onClick = { onDismiss(report.id) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEADBEE)),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Dismiss", fontSize = 12.sp, color = Color(0xFF22112E))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminStreamsTab(
    streams: List<LiveStream>,
    onEndStream: (String) -> Unit
) {
    if (streams.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No active live streams to moderate.")
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(streams) { stream ->
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AsyncImage(
                            model = stream.coverUrl,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(60.dp)
                                .clip(RoundedCornerShape(12.dp))
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = stream.title,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                maxLines = 1
                            )
                            Text(
                                text = "Host: ${stream.hostUser.displayName} • ${stream.viewerCount} Viewers",
                                style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray)
                            )
                            if (stream.guests.isNotEmpty()) {
                                Text(
                                    text = "👥 ${stream.guests.size} Guests on Stage",
                                    style = MaterialTheme.typography.labelSmall.copy(color = SanaPurpleSecondary)
                                )
                            }
                        }
                        IconButton(
                            onClick = { onEndStream(stream.id) },
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFFEBEE))
                        ) {
                            Icon(
                                imageVector = Icons.Default.CallEnd,
                                contentDescription = "Terminate Stream",
                                tint = SanaRedLive,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminUsersTab(
    users: List<User>,
    onToggleSuspend: (String, Boolean) -> Unit
) {
    var searchUserQuery by remember { mutableStateOf("") }
    val filtered = users.filter {
        it.displayName.contains(searchUserQuery, ignoreCase = true) ||
        it.username.contains(searchUserQuery, ignoreCase = true)
    }

    Column(modifier = Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = searchUserQuery,
            onValueChange = { searchUserQuery = it },
            placeholder = { Text("Search users to moderate...", fontSize = 13.sp) },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        )

        LazyColumn(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(filtered) { user ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            AsyncImage(
                                model = user.avatarUrl,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = user.displayName,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "@${user.username} • ${user.role.name}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray)
                                )
                            }
                        }

                        Button(
                            onClick = { onToggleSuspend(user.id, user.isBlocked) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (user.isBlocked) SanaPurpleSecondary else SanaRedLive
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (user.isBlocked) "Unban" else "Suspend",
                                fontSize = 11.sp,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminGiftsTab(
    giftStats: Map<GiftType, Int>
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0x33FF2E7E),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x66FF2E7E)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Virtual Gift Economics: 100% Free Guarantee",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = SanaPinkPrimary
                        )
                    )
                    Text(
                        text = "All ${GiftType.values().size} gifts have 0 coin cost. Displayed numbers (e.g. 200,000 or 80,000,000) are purely visual labels — users can send unlimited gifts without paying money.",
                        style = MaterialTheme.typography.bodySmall.copy(color = Color.DarkGray)
                    )
                }
            }
        }

        items(GiftType.values()) { gift ->
            val sentCount = giftStats[gift] ?: 0
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(text = gift.emoji, fontSize = 32.sp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = gift.giftName,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "${gift.slogan} • ${gift.displayedValueLabel}",
                                style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray)
                            )
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = SanaGoldAccent
                        ) {
                            Text(
                                text = "FREE",
                                color = Color.Black,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "$sentCount sent",
                            style = MaterialTheme.typography.labelSmall.copy(color = SanaPurpleSecondary)
                        )
                    }
                }
            }
        }
    }
}
