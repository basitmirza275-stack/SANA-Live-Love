package com.example.ui.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.UserRole
import com.example.data.repository.SanaRepository
import com.example.ui.components.SanaGradientButton
import com.example.ui.theme.SanaGoldAccent
import com.example.ui.theme.SanaPinkPrimary
import com.example.ui.theme.SanaPinkSoft
import com.example.ui.theme.SanaPurpleDark
import com.example.ui.theme.SanaPurpleSecondary
import com.example.ui.theme.SanaPurpleSoft

@Composable
fun ProfileScreen(
    repository: SanaRepository,
    onOpenAdminPanel: () -> Unit,
    onOpenCommunityGuidelines: () -> Unit
) {
    val user by repository.currentUser.collectAsState()
    val blockedIds by repository.blockedUserIds.collectAsState()
    val allUsers by repository.allUsers.collectAsState()

    var showEditProfileModal by remember { mutableStateOf(false) }
    var showBlockedListDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFFF9FB)),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // Profile Header Card
        item {
            ProfileHeader(
                user = user,
                onEditClick = { showEditProfileModal = true }
            )
        }

        // Stats Row
        item {
            ProfileStatsRow(
                followers = user.followersCount,
                following = user.followingCount,
                hearts = 48200
            )
        }

        // Role & Admin Switcher Banner (for user & admin convenience)
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(SanaPurpleSoft),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AdminPanelSettings,
                                contentDescription = null,
                                tint = SanaPurpleSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Admin & Moderation Mode",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = if (user.role == UserRole.ADMIN) "Admin features enabled" else "Standard user mode",
                                style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray)
                            )
                        }
                    }

                    Switch(
                        checked = user.role == UserRole.ADMIN,
                        onCheckedChange = { isChecked ->
                            repository.toggleRole(if (isChecked) UserRole.ADMIN else UserRole.USER)
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = SanaPurpleSecondary
                        ),
                        modifier = Modifier.testTag("admin_role_toggle")
                    )
                }
            }
        }

        // Action Menu List
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    // Admin Panel button (if Admin)
                    if (user.role == UserRole.ADMIN) {
                        ProfileMenuItem(
                            icon = Icons.Default.AdminPanelSettings,
                            title = "Admin Panel (Manage Streams & Reports)",
                            accentColor = SanaPurpleSecondary,
                            onClick = onOpenAdminPanel,
                            testTag = "open_admin_panel_button"
                        )
                    }

                    ProfileMenuItem(
                        icon = Icons.Default.Shield,
                        title = "Community Safety Guidelines",
                        accentColor = SanaPinkPrimary,
                        onClick = onOpenCommunityGuidelines,
                        testTag = "open_guidelines_button"
                    )

                    ProfileMenuItem(
                        icon = Icons.Default.Block,
                        title = "Blocked Users (${blockedIds.size})",
                        accentColor = Color(0xFF6B5875),
                        onClick = { showBlockedListDialog = true },
                        testTag = "manage_blocked_users_button"
                    )

                    ProfileMenuItem(
                        icon = Icons.Default.Lock,
                        title = "Account Privacy & Security",
                        accentColor = SanaPurpleSecondary,
                        onClick = { }
                    )
                }
            }
        }

        // Free Gifts Highlight info card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(SanaPinkSoft),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolunteerActivism,
                            contentDescription = null,
                            tint = SanaPinkPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column {
                        Text(
                            text = "Free Virtual Gifts Guarantee 🎁",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Every gift on SANA is 100% free. No payment or wallet required to support creators!",
                            style = MaterialTheme.typography.bodySmall.copy(color = Color.DarkGray)
                        )
                    }
                }
            }
        }
    }

    // Edit Profile Modal
    if (showEditProfileModal) {
        EditProfileModal(
            currentName = user.displayName,
            currentBio = user.bio,
            currentUsername = user.username,
            onSave = { name, username, bio, avatar ->
                repository.updateProfile(name, username, bio, avatar)
                showEditProfileModal = false
            },
            onDismiss = { showEditProfileModal = false }
        )
    }

    // Blocked users dialog
    if (showBlockedListDialog) {
        val blockedUsers = allUsers.filter { blockedIds.contains(it.id) }
        AlertDialog(
            onDismissRequest = { showBlockedListDialog = false },
            title = { Text("Blocked Users", fontWeight = FontWeight.Bold) },
            text = {
                if (blockedUsers.isEmpty()) {
                    Text("No blocked users. Your community is peaceful! 🌸")
                } else {
                    Column {
                        blockedUsers.forEach { u ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(u.displayName, fontWeight = FontWeight.Bold)
                                Button(
                                    onClick = { repository.unblockUser(u.id) },
                                    colors = ButtonDefaults.buttonColors(containerColor = SanaPurpleSecondary),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
                                ) {
                                    Text("Unblock", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showBlockedListDialog = false }) {
                    Text("Close")
                }
            }
        )
    }
}

@Composable
private fun ProfileHeader(
    user: com.example.data.model.User,
    onEditClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Box {
                AsyncImage(
                    model = user.avatarUrl,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(90.dp)
                        .clip(CircleShape)
                        .border(
                            2.5.dp,
                            Brush.linearGradient(listOf(SanaPinkPrimary, SanaPurpleSecondary)),
                            CircleShape
                        )
                )

                IconButton(
                    onClick = onEditClick,
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(SanaPinkPrimary)
                        .align(Alignment.BottomEnd)
                        .testTag("edit_profile_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Edit Profile",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = user.displayName,
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
                if (user.isVerified) {
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Verified",
                        tint = SanaPinkPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Text(
                text = "@${user.username}",
                style = MaterialTheme.typography.bodySmall.copy(color = SanaPurpleSecondary)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = user.bio,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = Color.DarkGray,
                    lineHeight = 18.sp
                ),
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }
    }
}

@Composable
private fun ProfileStatsRow(
    followers: Int,
    following: Int,
    hearts: Int
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            StatItem(label = "Followers", value = "${followers / 1000}.${(followers % 1000) / 100}k")
            Box(modifier = Modifier.width(1.dp).height(24.dp).background(Color(0xFFEADBEE)))
            StatItem(label = "Following", value = "$following")
            Box(modifier = Modifier.width(1.dp).height(24.dp).background(Color(0xFFEADBEE)))
            StatItem(label = "Hearts", value = "${hearts / 1000}k 💖")
        }
    }
}

@Composable
private fun StatItem(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray)
        )
    }
}

@Composable
private fun ProfileMenuItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    accentColor: Color,
    onClick: () -> Unit,
    testTag: String = "profile_menu_item"
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 12.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(accentColor.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accentColor,
                modifier = Modifier.size(18.dp)
            )
        }
        Spacer(modifier = Modifier.width(14.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
            modifier = Modifier.weight(1f)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditProfileModal(
    currentName: String,
    currentUsername: String,
    currentBio: String,
    onSave: (name: String, username: String, bio: String, avatar: String) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(currentName) }
    var username by remember { mutableStateOf(currentUsername) }
    var bio by remember { mutableStateOf(currentBio) }

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color.White,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .padding(bottom = 24.dp)
        ) {
            Text(
                text = "Edit Profile 🌸",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Display Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = username,
                onValueChange = { username = it },
                label = { Text("Username") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = bio,
                onValueChange = { bio = it },
                label = { Text("Bio") },
                maxLines = 3,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(20.dp))

            SanaGradientButton(
                text = "Save Changes",
                onClick = {
                    onSave(name, username, bio, "")
                },
                modifier = Modifier.fillMaxWidth(),
                testTag = "save_profile_button"
            )
        }
    }
}
