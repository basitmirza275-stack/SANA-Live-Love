package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// SANA Signature Colors: Cute, Romantic & Modern Pink/Purple/White Palette
val SanaPinkPrimary = Color(0xFFFF2E7E)
val SanaPinkLight = Color(0xFFFF649F)
val SanaPinkDark = Color(0xFFC70054)
val SanaPinkSoft = Color(0xFFFFE6EE)

val SanaPurpleSecondary = Color(0xFF8C3BFF)
val SanaPurpleLight = Color(0xFFB57AFF)
val SanaPurpleDark = Color(0xFF5B17C4)
val SanaPurpleSoft = Color(0xFFF3EBFF)

val SanaGoldAccent = Color(0xFFFFB800)
val SanaCyanAccent = Color(0xFF00E5FF)
val SanaGreenOnline = Color(0xFF00E676)
val SanaRedLive = Color(0xFFFF1744)

// Background & Surface Colors
val SanaSurfaceWhite = Color(0xFFFFFFFF)
val SanaBackgroundLight = Color(0xFFFFF7FA)
val SanaCardLight = Color(0xFFFFFFFF)
val SanaTextDark = Color(0xFF1E1424)
val SanaTextMuted = Color(0xFF7E6E85)

// Dark / Stream Mode Overlays
val SanaDarkBackground = Color(0xFF0E0716)
val SanaDarkSurface = Color(0xFF1B1128)
val SanaDarkCard = Color(0xFF261938)
val SanaDarkText = Color(0xFFFDEEF5)

// Gradient Brushes
val SanaGradientPrimary = Brush.horizontalGradient(
    listOf(SanaPinkPrimary, SanaPurpleSecondary)
)

val SanaGradientDiagonal = Brush.linearGradient(
    listOf(Color(0xFFFF3E8D), Color(0xFF9E3DFB), Color(0xFF6B11FF))
)

val SanaGradientSunset = Brush.linearGradient(
    listOf(Color(0xFFFF5284), Color(0xFFFF85A2), Color(0xFFBA68C8))
)

val SanaGradientSoftCard = Brush.verticalGradient(
    listOf(Color(0x22FF2E7E), Color(0x118C3BFF))
)

val SanaGradientDarkOverlay = Brush.verticalGradient(
    listOf(Color.Transparent, Color(0x99000000), Color(0xEE090310))
)
