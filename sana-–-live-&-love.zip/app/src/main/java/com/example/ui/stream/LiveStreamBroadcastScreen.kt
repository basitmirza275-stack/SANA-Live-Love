package com.example.ui.stream

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.model.GiftEvent
import com.example.data.model.LiveStream
import com.example.data.repository.SanaRepository
import com.example.ui.components.FloatingHeartsCanvas
import com.example.ui.components.FullscreenGiftCelebration
import com.example.ui.components.MultiGuestBadge
import com.example.ui.components.SanaGradientButton
import com.example.ui.components.SanaLiveBadge
import com.example.ui.theme.SanaGoldAccent
import com.example.ui.theme.SanaPinkPrimary
import com.example.ui.theme.SanaPurpleSecondary
import com.example.ui.theme.SanaRedLive
import kotlinx.coroutines.delay

@Composable
fun LiveStreamBroadcastScreen(
    streamId: String,
    repository: SanaRepository,
    onEndBroadcast: () -> Unit
) {
    val context = LocalContext.current
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        hasCameraPermission = permissions[Manifest.permission.CAMERA] == true
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
        }
    }

    BackHandler {
        // Confirm before ending broadcast
    }

    val liveStreams by repository.liveStreams.collectAsState()
    val stream = liveStreams.find { it.id == streamId }

    var isFrontCamera by remember { mutableStateOf(true) }
    var isMuted by remember { mutableStateOf(false) }
    var isBeautyFilterOn by remember { mutableStateOf(true) }
    var showEndDialog by remember { mutableStateOf(false) }
    var showSummaryDialog by remember { mutableStateOf(false) }
    var activeGiftCelebration by remember { mutableStateOf<GiftEvent?>(null) }
    var commentText by remember { mutableStateOf("") }
    var streamDurationSeconds by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            streamDurationSeconds++
        }
    }

    // Monitor recent gifts for celebration
    LaunchedEffect(stream?.recentGifts) {
        val latest = stream?.recentGifts?.firstOrNull()
        if (latest != null && activeGiftCelebration?.id != latest.id) {
            activeGiftCelebration = latest
        }
    }

    val commentsMap by repository.streamComments.collectAsState()
    val comments = if (stream != null) commentsMap[stream.id] ?: emptyList() else emptyList()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // Camera Preview Feed
        if (hasCameraPermission) {
            CameraPreview(
                isFrontCamera = isFrontCamera,
                isFilterActive = isBeautyFilterOn,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            // Permission request fallback card
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF140822)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Videocam,
                        contentDescription = null,
                        tint = SanaPinkPrimary,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Camera Permission Required",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Allow SANA to access your camera to broadcast live to friends!",
                        style = MaterialTheme.typography.bodyMedium.copy(color = Color.LightGray),
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    SanaGradientButton(
                        text = "Enable Camera",
                        onClick = {
                            permissionLauncher.launch(
                                arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
                            )
                        }
                    )
                }
            }
        }

        // Dark gradients
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color(0x99000000),
                            Color.Transparent,
                            Color(0x99000000),
                            Color(0xF0000000)
                        )
                    )
                )
        )

        // Floating Hearts Canvas
        FloatingHeartsCanvas(
            triggerHeartCount = stream?.likesCount ?: 0,
            modifier = Modifier.fillMaxSize()
        )

        // Broadcast Overlay
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SanaLiveBadge()
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0x88000000)
                    ) {
                        Text(
                            text = "${formatDuration(streamDurationSeconds)} • ${stream?.viewerCount ?: 1} Viewers",
                            color = Color.White,
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }

                // End Broadcast Button
                IconButton(
                    onClick = { showEndDialog = true },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(SanaRedLive)
                        .testTag("end_broadcast_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.CallEnd,
                        contentDescription = "End live",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Right-Side Floating Quick Controls
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.CenterEnd
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Flip Camera
                    IconButton(
                        onClick = { isFrontCamera = !isFrontCamera },
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Color(0x88000000))
                            .border(1.dp, Color(0x44FFFFFF), CircleShape)
                            .testTag("flip_camera_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Cameraswitch,
                            contentDescription = "Flip camera",
                            tint = Color.White
                        )
                    }

                    // Beauty Filter Toggle
                    IconButton(
                        onClick = { isBeautyFilterOn = !isBeautyFilterOn },
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(if (isBeautyFilterOn) SanaPinkPrimary else Color(0x88000000))
                            .border(1.dp, Color(0x44FFFFFF), CircleShape)
                            .testTag("beauty_filter_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "Beauty Filter",
                            tint = if (isBeautyFilterOn) Color.White else Color.LightGray
                        )
                    }

                    // Mic Mute Toggle
                    IconButton(
                        onClick = { isMuted = !isMuted },
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(if (isMuted) Color.Red else Color(0x88000000))
                            .border(1.dp, Color(0x44FFFFFF), CircleShape)
                            .testTag("mic_toggle_button")
                    ) {
                        Icon(
                            imageVector = if (isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                            contentDescription = "Mic toggle",
                            tint = Color.White
                        )
                    }

                    // Multi-Guest indicator
                    if (stream != null && stream.guests.isNotEmpty()) {
                        MultiGuestBadge(guestCount = stream.guests.size)
                    }
                }
            }

            // Bottom Area: Live Chat & Comments
            Column(modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .height(170.dp)
                ) {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(comments) { comment ->
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = if (comment.isGiftMessage) Color(0xDD3A1D4E) else Color(0x99000000),
                                border = if (comment.isGiftMessage) androidx.compose.foundation.BorderStroke(1.dp, SanaGoldAccent) else null,
                                modifier = Modifier.padding(vertical = 1.dp)
                            ) {
                                Text(
                                    text = "${comment.user.displayName}: ${comment.message}",
                                    color = if (comment.isGiftMessage) SanaGoldAccent else Color.White,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Chat Input for Host
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = commentText,
                        onValueChange = { commentText = it },
                        placeholder = { Text("Chat with your viewers... 🌸", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp) },
                        singleLine = true,
                        trailingIcon = {
                            if (commentText.isNotBlank()) {
                                IconButton(
                                    onClick = {
                                        if (stream != null) {
                                            repository.sendComment(stream.id, commentText)
                                            commentText = ""
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.Send, contentDescription = "Send", tint = SanaPinkPrimary)
                                }
                            }
                        },
                        shape = RoundedCornerShape(24.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color(0x88000000),
                            unfocusedContainerColor = Color(0x66000000),
                            focusedBorderColor = SanaPinkPrimary,
                            unfocusedBorderColor = Color(0x44FFFFFF),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                    )
                }
            }
        }

        // Fullscreen gift celebration animation
        FullscreenGiftCelebration(
            giftEvent = activeGiftCelebration,
            onAnimationEnd = { activeGiftCelebration = null }
        )

        // End Stream Confirmation Dialog
        if (showEndDialog) {
            AlertDialog(
                onDismissRequest = { showEndDialog = false },
                title = { Text("End Live Stream?", fontWeight = FontWeight.Bold) },
                text = { Text("Are you sure you want to end your broadcast? Your viewers will be notified.") },
                confirmButton = {
                    Button(
                        onClick = {
                            showEndDialog = false
                            if (stream != null) {
                                repository.endStream(stream.id)
                            }
                            showSummaryDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SanaRedLive)
                    ) {
                        Text("End Stream", color = Color.White)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showEndDialog = false }) {
                        Text("Continue Live")
                    }
                }
            )
        }

        // Stream Summary Dialog
        if (showSummaryDialog) {
            AlertDialog(
                onDismissRequest = {
                    showSummaryDialog = false
                    onEndBroadcast()
                },
                title = { Text("Broadcast Ended 🎉", fontWeight = FontWeight.Bold, color = SanaPinkPrimary) },
                text = {
                    Column {
                        Text("Great job streaming on SANA! Here is your summary:")
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("⏱️ Duration: ${formatDuration(streamDurationSeconds)}")
                        Text("👥 Total Viewers: ${stream?.viewerCount ?: 24}")
                        Text("💖 Hearts Earned: ${stream?.likesCount ?: 120}")
                        Text("🎁 Free Gifts Received: ${stream?.recentGifts?.size ?: 3}")
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("✨ Live Together, Smile Forever ✨", color = SanaPurpleSecondary, fontWeight = FontWeight.Bold)
                    }
                },
                confirmButton = {
                    SanaGradientButton(
                        text = "Finish",
                        onClick = {
                            showSummaryDialog = false
                            onEndBroadcast()
                        }
                    )
                }
            )
        }
    }
}

private fun formatDuration(seconds: Int): String {
    val mins = seconds / 60
    val secs = seconds % 60
    return String.format("%02d:%02d", mins, secs)
}
