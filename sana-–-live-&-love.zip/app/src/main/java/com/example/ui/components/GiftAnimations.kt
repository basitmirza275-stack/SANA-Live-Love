package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.GiftEvent
import com.example.data.model.GiftType
import com.example.ui.theme.SanaGoldAccent
import com.example.ui.theme.SanaPinkPrimary
import com.example.ui.theme.SanaPurpleSecondary
import kotlinx.coroutines.delay
import kotlin.math.sin
import kotlin.random.Random

data class FloatingParticle(
    val id: Long,
    val xRatio: Float,
    val size: Float,
    val color: Color,
    val speed: Float,
    val emoji: String? = null
)

@Composable
fun FloatingHeartsCanvas(
    triggerHeartCount: Int,
    modifier: Modifier = Modifier
) {
    val particles = remember { mutableStateListOf<FloatingParticle>() }

    LaunchedEffect(triggerHeartCount) {
        if (triggerHeartCount > 0) {
            val colors = listOf(
                Color(0xFFFF2E7E),
                Color(0xFFFF4081),
                Color(0xFFE040FB),
                Color(0xFFFF80AB),
                Color(0xFFFFD700)
            )
            val newParticle = FloatingParticle(
                id = System.nanoTime(),
                xRatio = 0.65f + Random.nextFloat() * 0.30f,
                size = 24f + Random.nextFloat() * 18f,
                color = colors.random(),
                speed = 0.8f + Random.nextFloat() * 0.5f,
                emoji = listOf("💖", "💕", "🌸", "✨", "❤️").random()
            )
            particles.add(newParticle)
        }
    }

    BoxWithConstraints(modifier = modifier) {
        val heightPx = constraints.maxHeight.toFloat().coerceAtLeast(100f)
        val widthPx = constraints.maxWidth.toFloat().coerceAtLeast(100f)

        particles.forEach { particle ->
            SingleFloatingHeart(
                particle = particle,
                totalHeight = heightPx,
                totalWidth = widthPx,
                onFinished = { particles.remove(particle) }
            )
        }
    }
}

@Composable
private fun SingleFloatingHeart(
    particle: FloatingParticle,
    totalHeight: Float,
    totalWidth: Float,
    onFinished: () -> Unit
) {
    val progress = remember { Animatable(0f) }

    LaunchedEffect(particle.id) {
        progress.animateTo(
            targetValue = 1f,
            animationSpec = tween(
                durationMillis = (1800 / particle.speed).toInt(),
                easing = LinearOutSlowInEasing
            )
        )
        onFinished()
    }

    val currentProgress = progress.value
    val yPos = totalHeight * (1f - currentProgress)
    val sway = sin(currentProgress * 8f) * 40f
    val xPos = (totalWidth * particle.xRatio) + sway
    val alpha = (1f - currentProgress).coerceIn(0f, 1f)
    val scale = (0.5f + (currentProgress * 0.7f)).coerceIn(0.5f, 1.3f)

    Box(
        modifier = Modifier
            .offset { IntOffset(xPos.toInt(), yPos.toInt()) }
            .graphicsLayer {
                this.alpha = alpha
                this.scaleX = scale
                this.scaleY = scale
            }
    ) {
        Text(
            text = particle.emoji ?: "💖",
            fontSize = particle.size.sp
        )
    }
}

/**
 * Fullscreen celebration overlay when ANY gift is sent (100% Free!).
 */
@Composable
fun FullscreenGiftCelebration(
    giftEvent: GiftEvent?,
    onAnimationEnd: () -> Unit
) {
    AnimatedVisibility(
        visible = giftEvent != null,
        enter = fadeIn(tween(200)) + scaleIn(tween(350, easing = FastOutSlowInEasing), initialScale = 0.25f),
        exit = fadeOut(tween(350)) + scaleOut(tween(350), targetScale = 1.3f)
    ) {
        if (giftEvent != null) {
            val displayDuration = if (giftEvent.giftType.isHugeCelebration) 4200L else 3200L

            LaunchedEffect(giftEvent.id) {
                delay(displayDuration)
                onAnimationEnd()
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x77000000)),
                contentAlignment = Alignment.Center
            ) {
                // Background radial sparkles
                GiftSparklesCanvas(
                    accentColor = Color(giftEvent.giftType.accentColorHex),
                    isMega = giftEvent.giftType.isHugeCelebration
                )

                // Custom Motion Effects for specific huge gifts
                when (giftEvent.giftType) {
                    GiftType.LUXURY_CAR -> SupercarFlybyAnimation()
                    GiftType.PRIVATE_JET -> JetFlightAnimation()
                    GiftType.FIREWORKS -> FireworksBurstCanvas()
                    else -> Unit
                }

                // Center animated stage
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(20.dp)
                ) {
                    // Top banner announcement
                    GiftBannerPill(giftEvent = giftEvent)

                    Spacer(modifier = Modifier.height(20.dp))

                    // Big Animated Gift Centerpiece
                    BigGiftCenterpiece(giftType = giftEvent.giftType)

                    Spacer(modifier = Modifier.height(20.dp))

                    // Gift Slogan & 100% Free badge
                    Surface(
                        shape = RoundedCornerShape(24.dp),
                        color = Color(0xDD180A2A),
                        border = androidx.compose.foundation.BorderStroke(
                            1.5.dp,
                            Brush.horizontalGradient(
                                listOf(
                                    Color(giftEvent.giftType.accentColorHex),
                                    SanaGoldAccent,
                                    SanaPinkPrimary
                                )
                            )
                        ),
                        modifier = Modifier.padding(horizontal = 16.dp)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp)
                        ) {
                            Text(
                                text = giftEvent.giftType.slogan,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                ),
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = SanaGoldAccent
                                ) {
                                    Text(
                                        text = giftEvent.giftType.displayedValueLabel,
                                        color = Color.Black,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Black,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "• 0 COINS REQUIRED",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "✨ 100% UNLIMITED FREE GIFT • NO PURCHASE ✨",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = SanaPinkPrimary
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GiftBannerPill(giftEvent: GiftEvent) {
    Surface(
        shape = RoundedCornerShape(32.dp),
        color = Color(0xDD000000),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            Brush.horizontalGradient(listOf(Color(giftEvent.giftType.accentColorHex), SanaPinkPrimary))
        ),
        shadowElevation = 8.dp
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            AsyncImage(
                model = giftEvent.sender.avatarUrl,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .border(1.5.dp, SanaPinkPrimary, CircleShape)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = giftEvent.sender.displayName,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                )
                Text(
                    text = "sent free ${giftEvent.giftType.giftName} ${giftEvent.giftType.emoji}",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = Color(0xFFFFD54F),
                        fontWeight = FontWeight.Bold
                    )
                )
            }
        }
    }
}

@Composable
private fun BigGiftCenterpiece(giftType: GiftType) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = if (giftType.isHugeCelebration) 0.95f else 0.90f,
        targetValue = if (giftType.isHugeCelebration) 1.25f else 1.12f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )
    val rotation by infiniteTransition.animateFloat(
        initialValue = -6f,
        targetValue = 6f,
        animationSpec = infiniteRepeatable(
            animation = tween(650, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "rotation"
    )

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .size(if (giftType.isHugeCelebration) 200.dp else 160.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                rotationZ = rotation
            }
    ) {
        // Glowing radial aura
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(giftType.accentColorHex).copy(alpha = 0.7f),
                        Color(giftType.accentColorHex).copy(alpha = 0.3f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = size.minDimension / 1.4f
                )
            )
        }

        // Main Gift Emoji
        Text(
            text = giftType.emoji,
            fontSize = if (giftType.isHugeCelebration) 105.sp else 88.sp
        )
    }
}

@Composable
private fun SupercarFlybyAnimation() {
    val carAnim = remember { Animatable(-300f) }
    LaunchedEffect(Unit) {
        carAnim.animateTo(
            targetValue = 900f,
            animationSpec = tween(1600, easing = FastOutSlowInEasing)
        )
    }
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .offset { IntOffset(carAnim.value.toInt(), 120) }
    ) {
        Text(text = "🏎️💨💨💖", fontSize = 48.sp)
    }
}

@Composable
private fun JetFlightAnimation() {
    val jetAnim = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        jetAnim.animateTo(
            targetValue = 1f,
            animationSpec = tween(2200, easing = LinearOutSlowInEasing)
        )
    }
    val progress = jetAnim.value
    val x = (-100f + progress * 700f).toInt()
    val y = (350f - progress * 400f).toInt()

    Box(
        modifier = Modifier
            .offset { IntOffset(x, y) }
            .graphicsLayer {
                rotationZ = -25f
            }
    ) {
        Text(text = "✈️✨✨", fontSize = 52.sp)
    }
}

@Composable
private fun FireworksBurstCanvas() {
    val infiniteTransition = rememberInfiniteTransition(label = "fireworks")
    val radiusRatio by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "fw_rad"
    )

    Canvas(modifier = Modifier.fillMaxSize()) {
        val colors = listOf(Color.Yellow, Color.Magenta, Color.Cyan, Color.White, Color(0xFFFF2E7E))
        for (i in 0 until 18) {
            val angle = (i * 20f) * (Math.PI / 180f).toFloat()
            val dist = (size.minDimension * 0.45f) * radiusRatio
            val x = center.x + kotlin.math.cos(angle) * dist
            val y = center.y + kotlin.math.sin(angle) * dist
            drawCircle(
                color = colors[i % colors.size].copy(alpha = (1f - radiusRatio).coerceIn(0f, 1f)),
                radius = 6.dp.toPx() * (1f - radiusRatio * 0.5f),
                center = Offset(x, y)
            )
        }
    }
}

@Composable
private fun GiftSparklesCanvas(accentColor: Color, isMega: Boolean = false) {
    val infiniteTransition = rememberInfiniteTransition(label = "sparkles")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isMega) 6000 else 12000, easing = LinearEasing)
        ),
        label = "rot"
    )

    Canvas(modifier = Modifier.fillMaxSize()) {
        rotate(rotation) {
            val count = if (isMega) 36 else 24
            for (i in 0 until count) {
                val angle = (i * 360f / count) * (Math.PI / 180f).toFloat()
                val dist = (size.minDimension * 0.38f) + ((i % 3) * 30f)
                val x = center.x + kotlin.math.cos(angle) * dist
                val y = center.y + kotlin.math.sin(angle) * dist
                val radius = if (i % 2 == 0) 5.dp.toPx() else 3.dp.toPx()
                val sparkleColor = if (i % 2 == 0) accentColor else Color.White
                drawCircle(
                    color = sparkleColor.copy(alpha = 0.75f),
                    radius = radius,
                    center = Offset(x, y)
                )
            }
        }
    }
}
