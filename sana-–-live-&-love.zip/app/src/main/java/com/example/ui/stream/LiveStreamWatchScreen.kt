package com.example.ui.stream

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.GiftEvent
import com.example.data.model.GuestUser
import com.example.data.model.LiveComment
import com.example.data.model.LiveStream
import com.example.data.repository.SanaRepository
import com.example.ui.components.FloatingHeartsCanvas
import com.example.ui.components.FullscreenGiftCelebration
import com.example.ui.components.MultiGuestBadge
import com.example.ui.components.SanaFollowButton
import com.example.ui.components.SanaLiveBadge
import com.example.ui.theme.SanaGoldAccent
import com.example.ui.theme.SanaPinkPrimary
import com.example.ui.theme.SanaPurpleSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiveStreamWatchScreen(
    streamId: String,
    repository: SanaRepository,
    onClose: () -> Unit,
    onOpenReport: (userId: String, userName: String, streamId: String) -> Unit
) {
    BackHandler { onClose() }

    val liveStreams by repository.liveStreams.collectAsState()
    val stream = liveStreams.find { it.id == streamId } ?: liveStreams.firstOrNull()

    if (stream == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            Text("Stream ended", color = Color.White)
        }
        return
    }

    val currentUser by repository.currentUser.collectAsState()
    val commentsMap by repository.streamComments.collectAsState()
    val comments = commentsMap[stream.id] ?: emptyList()
    val isFollowing = repository.isFollowing(stream.hostUser.id)
    val isCurrentGuest = stream.guests.any { it.id == currentUser.id }

    var heartCount by remember { mutableIntStateOf(0) }
    var showGiftModal by remember { mutableStateOf(false) }
    var activeGiftCelebration by remember { mutableStateOf<GiftEvent?>(null) }
    var commentInput by remember { mutableStateOf("") }
    var showMenu by remember { mutableStateOf(false) }

    val listState = rememberLazyListState()
    LaunchedEffect(comments.size) {
        if (comments.isNotEmpty()) {
            listState.animateScrollToItem(comments.size - 1)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0D0614))
            .pointerInput(Unit) {
                detectTapGestures(
                    onDoubleTap = {
                        heartCount++
                        repository.tapHeart(stream.id)
                    }
                )
            }
    ) {
        // Video Stage (Host + Multi-Guests layout)
        StreamVideoStage(
            stream = stream,
            isCurrentGuest = isCurrentGuest
        )

        // Gradient dark overlay on top & bottom for readability
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color(0x99000000),
                            Color.Transparent,
                            Color.Transparent,
                            Color(0xCC000000),
                            Color(0xF0080210)
                        )
                    )
                )
        )

        // Floating Hearts Particle Canvas
        FloatingHeartsCanvas(
            triggerHeartCount = heartCount,
            modifier = Modifier.fillMaxSize()
        )

        // Main UI Overlay
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Bar
            StreamTopBar(
                stream = stream,
                isFollowing = isFollowing,
                onFollowToggle = { repository.toggleFollow(stream.hostUser.id) },
                onClose = onClose,
                onOpenMenu = { showMenu = true }
            )

            // Center / Middle area (shows room title and guest stage highlight)
            Column {
                // Room Title Pill
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0x66000000),
                    modifier = Modifier.padding(bottom = 6.dp)
                ) {
                    Text(
                        text = stream.title,
                        color = Color.White.copy(alpha = 0.9f),
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }

                if (stream.guests.isNotEmpty()) {
                    MultiGuestBadge(
                        guestCount = stream.guests.size,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }
            }

            // Bottom Area: Chat Comments & Control Bar
            Column(modifier = Modifier.fillMaxWidth()) {
                // Live Chat Scrolling List
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .height(180.dp)
                ) {
                    LazyColumn(
                        state = listState,
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(comments) { comment ->
                            ChatCommentBubble(comment = comment)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Bottom Action Bar
                StreamBottomBar(
                    commentInput = commentInput,
                    onCommentChange = { commentInput = it },
                    onSendComment = {
                        if (commentInput.isNotBlank()) {
                            repository.sendComment(stream.id, commentInput)
                            commentInput = ""
                        }
                    },
                    isGuest = isCurrentGuest,
                    onGuestToggle = {
                        if (isCurrentGuest) {
                            repository.leaveGuestStage(stream.id)
                        } else {
                            repository.joinAsGuest(stream.id)
                        }
                    },
                    onOpenGifts = { showGiftModal = true },
                    onTapHeart = {
                        heartCount++
                        repository.tapHeart(stream.id)
                    },
                    likesCount = stream.likesCount
                )
            }
        }

        // Room Settings & Report Dropdown Menu
        DropdownMenu(
            expanded = showMenu,
            onDismissRequest = { showMenu = false }
        ) {
            DropdownMenuItem(
                text = { Text("Report Inappropriate Content") },
                leadingIcon = { Icon(Icons.Default.Shield, contentDescription = null, tint = SanaPinkPrimary) },
                onClick = {
                    showMenu = false
                    onOpenReport(stream.hostUser.id, stream.hostUser.displayName, stream.id)
                }
            )
            DropdownMenuItem(
                text = { Text("Block Host") },
                onClick = {
                    showMenu = false
                    repository.blockUser(stream.hostUser.id)
                    onClose()
                }
            )
        }

        // Free Gifts Modal
        if (showGiftModal) {
            GiftSelectionModal(
                onGiftSelected = { giftType ->
                    val event = repository.sendFreeGift(stream.id, giftType)
                    activeGiftCelebration = event
                },
                onDismiss = { showGiftModal = false }
            )
        }

        // Fullscreen celebration overlay
        FullscreenGiftCelebration(
            giftEvent = activeGiftCelebration,
            onAnimationEnd = { activeGiftCelebration = null }
        )
    }
}

@Composable
private fun StreamTopBar(
    stream: LiveStream,
    isFollowing: Boolean,
    onFollowToggle: () -> Unit,
    onClose: () -> Unit,
    onOpenMenu: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Host Info Pill
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color(0x88000000),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x33FFFFFF))
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(start = 4.dp, end = 10.dp, top = 4.dp, bottom = 4.dp)
            ) {
                AsyncImage(
                    model = stream.hostUser.avatarUrl,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .border(1.5.dp, SanaPinkPrimary, CircleShape)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = stream.hostUser.displayName,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${stream.viewerCount} watching",
                        style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFFE0D0EA))
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                SanaFollowButton(
                    isFollowing = isFollowing,
                    onToggle = onFollowToggle
                )
            }
        }

        // Right controls: Live badge + Menu + Close
        Row(verticalAlignment = Alignment.CenterVertically) {
            SanaLiveBadge()
            Spacer(modifier = Modifier.width(6.dp))
            IconButton(
                onClick = onOpenMenu,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(0x66000000))
            ) {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "Menu",
                    tint = Color.White
                )
            }
            Spacer(modifier = Modifier.width(6.dp))
            IconButton(
                onClick = onClose,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(0x66000000))
                    .testTag("close_stream_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Close stream",
                    tint = Color.White
                )
            }
        }
    }
}

/**
 * Multi-guest video layout:
 * If no guests -> Host video occupies full stage
 * If 1 guest -> Split 70% host / 30% guest slot
 * If 2 guests -> Split host top/left + 2 guest slots with live badges
 */
@Composable
private fun StreamVideoStage(
    stream: LiveStream,
    isCurrentGuest: Boolean
) {
    Box(modifier = Modifier.fillMaxSize()) {
        if (stream.guests.isEmpty()) {
            // Full screen single host view
            AsyncImage(
                model = stream.coverUrl,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            // Multi-guest split view
            Column(modifier = Modifier.fillMaxSize()) {
                // Host Video (upper 65%)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    AsyncImage(
                        model = stream.coverUrl,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xAA000000),
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(8.dp)
                    ) {
                        Text(
                            text = "👑 Host • ${stream.hostUser.displayName}",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }

                // Guests row (lower 35%)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(170.dp)
                        .background(Color(0xFF140B22))
                        .padding(horizontal = 4.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    stream.guests.forEach { guest ->
                        GuestStageSlot(
                            guest = guest,
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun GuestStageSlot(
    guest: GuestUser,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF23163A))
            .border(1.dp, Brush.linearGradient(listOf(SanaPinkPrimary, SanaPurpleSecondary)), RoundedCornerShape(14.dp))
    ) {
        AsyncImage(
            model = guest.avatarUrl,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Gradient at bottom of guest slot
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, Color(0xCC000000))
                    )
                )
        )

        // Mic & Guest Name
        Row(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (guest.isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                contentDescription = null,
                tint = if (guest.isMuted) Color.Red else Color.Green,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = guest.displayName,
                color = Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun ChatCommentBubble(comment: LiveComment) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = if (comment.isGiftMessage) Color(0xDD3A1D4E) else Color(0x99000000),
        border = if (comment.isGiftMessage) {
            androidx.compose.foundation.BorderStroke(1.dp, SanaGoldAccent)
        } else null,
        modifier = Modifier.padding(vertical = 1.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            AsyncImage(
                model = comment.user.avatarUrl,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(20.dp)
                    .clip(CircleShape)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = comment.user.displayName + ": ",
                color = if (comment.isGiftMessage) SanaGoldAccent else Color(0xFFFF85A2),
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
            )
            Text(
                text = comment.message,
                color = Color.White,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun StreamBottomBar(
    commentInput: String,
    onCommentChange: (String) -> Unit,
    onSendComment: () -> Unit,
    isGuest: Boolean,
    onGuestToggle: () -> Unit,
    onOpenGifts: () -> Unit,
    onTapHeart: () -> Unit,
    likesCount: Int
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Comment input field
        OutlinedTextField(
            value = commentInput,
            onValueChange = onCommentChange,
            placeholder = {
                Text(
                    "Say something nice... 💖",
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 12.sp
                )
            },
            singleLine = true,
            trailingIcon = {
                if (commentInput.isNotBlank()) {
                    IconButton(
                        onClick = onSendComment,
                        modifier = Modifier.testTag("send_comment_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Send",
                            tint = SanaPinkPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            },
            shape = RoundedCornerShape(24.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color(0x88000000),
                unfocusedContainerColor = Color(0x66000000),
                focusedBorderColor = SanaPinkPrimary,
                unfocusedBorderColor = Color(0x44FFFFFF),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            ),
            modifier = Modifier
                .weight(1f)
                .height(50.dp)
                .testTag("comment_input_field")
        )

        // Multi-Guest Join Button
        IconButton(
            onClick = onGuestToggle,
            modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(if (isGuest) SanaPinkPrimary else Color(0x88000000))
                .border(1.dp, SanaPurpleSecondary, CircleShape)
                .testTag("join_guest_stage_button")
        ) {
            Icon(
                imageVector = Icons.Default.GroupAdd,
                contentDescription = if (isGuest) "Leave stage" else "Join guest stage",
                tint = Color.White,
                modifier = Modifier.size(22.dp)
            )
        }

        // Free Gifts Button (🎁 100% Free)
        IconButton(
            onClick = onOpenGifts,
            modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(SanaPinkPrimary, SanaPurpleSecondary)))
                .testTag("open_gifts_button")
        ) {
            Icon(
                imageVector = Icons.Default.VolunteerActivism,
                contentDescription = "Free Gifts",
                tint = Color.White,
                modifier = Modifier.size(24.dp)
            )
        }

        // Floating Heart Tap Button
        Surface(
            shape = CircleShape,
            color = Color(0x88000000),
            border = androidx.compose.foundation.BorderStroke(1.dp, SanaPinkPrimary),
            modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .clickable { onTapHeart() }
                .testTag("tap_heart_button")
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = Icons.Default.Favorite,
                    contentDescription = "Send Love",
                    tint = SanaPinkPrimary,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}
