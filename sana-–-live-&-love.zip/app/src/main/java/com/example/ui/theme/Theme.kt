package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = SanaPinkLight,
    onPrimary = Color.White,
    primaryContainer = SanaPinkDark,
    onPrimaryContainer = SanaPinkSoft,
    secondary = SanaPurpleLight,
    onSecondary = Color.White,
    secondaryContainer = SanaPurpleDark,
    onSecondaryContainer = SanaPurpleSoft,
    tertiary = SanaGoldAccent,
    background = SanaDarkBackground,
    onBackground = SanaDarkText,
    surface = SanaDarkSurface,
    onSurface = SanaDarkText,
    surfaceVariant = SanaDarkCard,
    onSurfaceVariant = Color(0xFFDEC5D9)
)

private val LightColorScheme = lightColorScheme(
    primary = SanaPinkPrimary,
    onPrimary = Color.White,
    primaryContainer = SanaPinkSoft,
    onPrimaryContainer = SanaPinkDark,
    secondary = SanaPurpleSecondary,
    onSecondary = Color.White,
    secondaryContainer = SanaPurpleSoft,
    onSecondaryContainer = SanaPurpleDark,
    tertiary = SanaGoldAccent,
    background = SanaBackgroundLight,
    onBackground = SanaTextDark,
    surface = SanaSurfaceWhite,
    onSurface = SanaTextDark,
    surfaceVariant = Color(0xFFF9EEF3),
    onSurfaceVariant = SanaTextMuted
)

val SanaShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(36.dp)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            window?.let {
                WindowCompat.setDecorFitsSystemWindows(it, false)
                it.statusBarColor = Color.Transparent.toArgb()
                it.navigationBarColor = Color.Transparent.toArgb()
                WindowCompat.getInsetsController(it, view).isAppearanceLightStatusBars = !darkTheme
                WindowCompat.getInsetsController(it, view).isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = SanaShapes,
        content = content
    )
}
