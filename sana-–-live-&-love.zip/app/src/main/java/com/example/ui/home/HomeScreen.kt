package com.example.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.LiveStream
import com.example.data.model.User
import com.example.data.repository.SanaRepository
import com.example.ui.components.MultiGuestBadge
import com.example.ui.components.OnlineStatusIndicator
import com.example.ui.components.SanaCategoryChip
import com.example.ui.components.SanaFollowButton
import com.example.ui.components.SanaLiveBadge
import com.example.ui.theme.SanaGoldAccent
import com.example.ui.theme.SanaGradientPrimary
import com.example.ui.theme.SanaPinkPrimary
import com.example.ui.theme.SanaPinkSoft
import com.example.ui.theme.SanaPurpleDark
import com.example.ui.theme.SanaPurpleSecondary
import com.example.ui.theme.SanaPurpleSoft

@Composable
fun HomeScreen(
    repository: SanaRepository,
    onSelectStream: (String) -> Unit,
    onGoLiveClick: () -> Unit,
    onOpenNotifications: () -> Unit
) {
    val streams by repository.liveStreams.collectAsState()
    val allUsers by repository.allUsers.collectAsState()
    val currentUser by repository.currentUser.collectAsState()
    val blockedIds by repository.blockedUserIds.collectAsState()

    // Filter out blocked creators
    val visibleStreams = streams.filterNot { blockedIds.contains(it.hostUser.id) }
    val recommendedCreators = allUsers.filter { it.id != currentUser.id && !blockedIds.contains(it.id) }

    var selectedCategory by remember { mutableStateOf("All") }
    val categories = listOf("All", "Trending", "Multi-Guest", "Singing", "Chit-Chat", "Dancing", "Gaming")

    val filteredStreams = visibleStreams.filter { stream ->
        when (selectedCategory) {
            "All" -> true
            "Trending" -> stream.viewerCount > 1500
            "Multi-Guest" -> stream.guests.isNotEmpty()
            else -> stream.category.equals(selectedCategory, ignoreCase = true) ||
                    stream.tags.any { it.equals(selectedCategory, ignoreCase = true) }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFFF9FB)),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // App Header: Logo + Tagline + Actions
        item {
            SanaHomeHeader(
                onOpenNotifications = onOpenNotifications,
                unreadNotificationCount = 2
            )
        }

        // Welcome / Free Gifts Hero Card
        item {
            SanaHeroBanner(
                onGoLiveClick = onGoLiveClick
            )
        }

        // Category Filter Chips
        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(categories) { category ->
                    SanaCategoryChip(
                        text = category,
                        isSelected = selectedCategory == category,
                        onClick = { selectedCategory = category }
                    )
                }
            }
        }

        // Section Title: Live Streaming Rooms
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (selectedCategory == "All") "Trending Live Streams" else "$selectedCategory Rooms",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF22112E)
                        )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    SanaLiveBadge()
                }

                Text(
                    text = "${filteredStreams.size} Active",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = SanaPurpleSecondary,
                        fontWeight = FontWeight.SemiBold
                    )
                )
            }
        }

        // Live Streams Cards Grid (2 columns)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
            ) {
                val chunked = filteredStreams.chunked(2)
                chunked.forEach { pair ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        pair.forEach { stream ->
                            Box(modifier = Modifier.weight(1f)) {
                                LiveStreamCard(
                                    stream = stream,
                                    onClick = { onSelectStream(stream.id) }
                                )
                            }
                        }
                        if (pair.size == 1) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }

        // Section Title: Recommended Creators
        item {
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Recommended Creators 💖",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF22112E)
                    )
                )
            }
        }

        // Creators Carousel
        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(recommendedCreators) { creator ->
                    RecommendedCreatorCard(
                        creator = creator,
                        isFollowing = repository.isFollowing(creator.id),
                        onToggleFollow = { repository.toggleFollow(creator.id) },
                        onSelect = {
                            val activeStream = visibleStreams.find { it.hostUser.id == creator.id }
                            if (activeStream != null) {
                                onSelectStream(activeStream.id)
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun SanaHomeHeader(
    onOpenNotifications: () -> Unit,
    unreadNotificationCount: Int
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Heart Emblem
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(SanaGradientPrimary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Favorite,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "SANA",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.Black,
                        color = SanaPinkPrimary,
                        letterSpacing = 1.sp
                    )
                )
                Spacer(modifier = Modifier.width(6.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = SanaPurpleSoft
                ) {
                    Text(
                        text = "Live & Love",
                        color = SanaPurpleSecondary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
            Text(
                text = "Live Together, Smile Forever",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = Color(0xFF7A6484),
                    fontWeight = FontWeight.Medium
                ),
                modifier = Modifier.padding(start = 40.dp)
            )
        }

        // Notification Bell with Badge
        Box {
            IconButton(
                onClick = onOpenNotifications,
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Color.White)
                    .border(1.dp, Color(0xFFFFD1DF), CircleShape)
                    .testTag("notifications_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Notifications,
                    contentDescription = "Notifications",
                    tint = SanaPurpleSecondary
                )
            }
            if (unreadNotificationCount > 0) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(SanaPinkPrimary)
                        .align(Alignment.TopEnd)
                )
            }
        }
    }
}

@Composable
private fun SanaHeroBanner(
    onGoLiveClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
                .background(
                    Brush.linearGradient(
                        listOf(Color(0xFFFF2E7E), Color(0xFF9C27B0), Color(0xFF673AB7))
                    )
                )
        ) {
            // Content
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(18.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0x33FFFFFF)
                    ) {
                        Text(
                            text = "🎁 100% FREE VIRTUAL GIFTS",
                            color = SanaGoldAccent,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Roses, Supercars, Jets & 80M Infinity!",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                    Text(
                        text = "100% Free! Unlimited gifts with 0 coins required ✨",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    )
                }

                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color.White,
                    shadowElevation = 4.dp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .clickable { onGoLiveClick() }
                        .testTag("hero_go_live_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Videocam,
                            contentDescription = null,
                            tint = SanaPinkPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Go Live",
                            color = SanaPinkPrimary,
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LiveStreamCard(
    stream: LiveStream,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .clickable { onClick() }
            .testTag("stream_card_${stream.id}")
    ) {
        Column {
            // Cover Image with Badges
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(170.dp)
            ) {
                AsyncImage(
                    model = stream.coverUrl,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Dark gradient bottom
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, Color(0xAA000000))
                            )
                        )
                )

                // Top badges: Live + Guest badge
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SanaLiveBadge()
                    if (stream.guests.isNotEmpty()) {
                        MultiGuestBadge(guestCount = stream.guests.size)
                    }
                }

                // Bottom row in image: Viewers count
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0x88000000),
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(8.dp)
                ) {
                    Text(
                        text = "👀 ${stream.viewerCount}",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            // Host & Info below image
            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = stream.title,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1E1424)
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        AsyncImage(
                            model = stream.hostUser.avatarUrl,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(20.dp)
                                .clip(CircleShape)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = stream.hostUser.displayName,
                            style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFF6D5A75)),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    // Category Pill
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = SanaPinkSoft
                    ) {
                        Text(
                            text = stream.category,
                            color = SanaPinkPrimary,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun RecommendedCreatorCard(
    creator: User,
    isFollowing: Boolean,
    onToggleFollow: () -> Unit,
    onSelect: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
        modifier = Modifier
            .width(135.dp)
            .clip(RoundedCornerShape(20.dp))
            .clickable { onSelect() }
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(12.dp)
        ) {
            Box {
                AsyncImage(
                    model = creator.avatarUrl,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .border(1.5.dp, SanaPinkPrimary, CircleShape)
                )
                OnlineStatusIndicator(
                    isOnline = creator.isOnline,
                    modifier = Modifier.align(Alignment.BottomEnd)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = creator.displayName,
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = "${creator.followersCount / 1000}k fans",
                style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray),
                fontSize = 10.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            SanaFollowButton(
                isFollowing = isFollowing,
                onToggle = onToggleFollow
            )
        }
    }
}
