package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.SanaRepository
import com.example.ui.admin.AdminPanelScreen
import com.example.ui.explore.ExploreScreen
import com.example.ui.home.HomeScreen
import com.example.ui.messages.MessagesScreen
import com.example.ui.profile.ProfileScreen
import com.example.ui.safety.CommunityGuidelinesModal
import com.example.ui.safety.ReportContentDialog
import com.example.ui.stream.GoLiveSetupModal
import com.example.ui.stream.LiveStreamBroadcastScreen
import com.example.ui.stream.LiveStreamWatchScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.SanaGoldAccent
import com.example.ui.theme.SanaPinkPrimary
import com.example.ui.theme.SanaPinkSoft
import com.example.ui.theme.SanaPurpleSecondary

sealed class Screen {
    object Home : Screen()
    object Explore : Screen()
    object Messages : Screen()
    object Profile : Screen()
    data class WatchStream(val streamId: String) : Screen()
    data class Broadcast(val streamId: String) : Screen()
    object AdminPanel : Screen()
}

data class ReportTarget(
    val userId: String,
    val userName: String,
    val streamId: String?
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val repository = SanaRepository()

        setContent {
            MyApplicationTheme {
                SanaApp(repository = repository)
            }
        }
    }
}

@Composable
fun SanaApp(repository: SanaRepository) {
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Home) }
    var showGoLiveModal by remember { mutableStateOf(false) }
    var showCommunityGuidelines by remember { mutableStateOf(false) }
    var activeReportTarget by remember { mutableStateOf<ReportTarget?>(null) }

    // Check if bottom bar should be shown (hidden during live watching/broadcasting or admin panel)
    val showBottomBar = currentScreen is Screen.Home ||
            currentScreen is Screen.Explore ||
            currentScreen is Screen.Messages ||
            currentScreen is Screen.Profile

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = Color(0xFFFFF9FB),
        bottomBar = {
            if (showBottomBar) {
                SanaBottomNavigationBar(
                    currentScreen = currentScreen,
                    onNavigate = { screen -> currentScreen = screen },
                    onGoLiveClick = { showGoLiveModal = true }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = if (showBottomBar) innerPadding.calculateBottomPadding() else 0.dp)
        ) {
            when (val screen = currentScreen) {
                is Screen.Home -> {
                    HomeScreen(
                        repository = repository,
                        onSelectStream = { streamId -> currentScreen = Screen.WatchStream(streamId) },
                        onGoLiveClick = { showGoLiveModal = true },
                        onOpenNotifications = { currentScreen = Screen.Messages }
                    )
                }
                is Screen.Explore -> {
                    ExploreScreen(
                        repository = repository,
                        onSelectStream = { streamId -> currentScreen = Screen.WatchStream(streamId) }
                    )
                }
                is Screen.Messages -> {
                    MessagesScreen(
                        repository = repository,
                        onOpenReport = { userId, userName, streamId ->
                            activeReportTarget = ReportTarget(userId, userName, streamId)
                        }
                    )
                }
                is Screen.Profile -> {
                    ProfileScreen(
                        repository = repository,
                        onOpenAdminPanel = { currentScreen = Screen.AdminPanel },
                        onOpenCommunityGuidelines = { showCommunityGuidelines = true }
                    )
                }
                is Screen.WatchStream -> {
                    LiveStreamWatchScreen(
                        streamId = screen.streamId,
                        repository = repository,
                        onClose = { currentScreen = Screen.Home },
                        onOpenReport = { userId, userName, streamId ->
                            activeReportTarget = ReportTarget(userId, userName, streamId)
                        }
                    )
                }
                is Screen.Broadcast -> {
                    LiveStreamBroadcastScreen(
                        streamId = screen.streamId,
                        repository = repository,
                        onEndBroadcast = { currentScreen = Screen.Home }
                    )
                }
                is Screen.AdminPanel -> {
                    AdminPanelScreen(
                        repository = repository,
                        onBack = { currentScreen = Screen.Profile }
                    )
                }
            }
        }
    }

    // Go Live Setup BottomSheet Modal
    if (showGoLiveModal) {
        GoLiveSetupModal(
            onStartStream = { title, category, allowGuests ->
                val newStream = repository.startBroadcast(title, category, allowGuests)
                currentScreen = Screen.Broadcast(newStream.id)
            },
            onDismiss = { showGoLiveModal = false }
        )
    }

    // Community Guidelines Modal
    if (showCommunityGuidelines) {
        CommunityGuidelinesModal(
            onDismiss = { showCommunityGuidelines = false }
        )
    }

    // Content Report Dialog
    if (activeReportTarget != null) {
        val target = activeReportTarget!!
        ReportContentDialog(
            targetUserName = target.userName,
            onSubmitReport = { reason, details ->
                repository.submitReport(
                    reportedUserId = target.userId,
                    reportedUserName = target.userName,
                    streamId = target.streamId,
                    reason = reason,
                    details = details
                )
                activeReportTarget = null
            },
            onDismiss = { activeReportTarget = null }
        )
    }
}

@Composable
fun SanaBottomNavigationBar(
    currentScreen: Screen,
    onNavigate: (Screen) -> Unit,
    onGoLiveClick: () -> Unit
) {
    Surface(
        color = Color.White,
        shadowElevation = 8.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.navigationBars)
                .height(64.dp)
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Home
            val isHome = currentScreen is Screen.Home
            BottomNavItem(
                icon = if (isHome) Icons.Filled.Home else Icons.Outlined.Home,
                label = "Home",
                isSelected = isHome,
                onClick = { onNavigate(Screen.Home) },
                modifier = Modifier.weight(1f),
                testTag = "nav_home"
            )

            // Explore
            val isExplore = currentScreen is Screen.Explore
            BottomNavItem(
                icon = if (isExplore) Icons.Filled.Explore else Icons.Outlined.Explore,
                label = "Explore",
                isSelected = isExplore,
                onClick = { onNavigate(Screen.Explore) },
                modifier = Modifier.weight(1f),
                testTag = "nav_explore"
            )

            // Center Go Live Special Button
            Box(
                modifier = Modifier
                    .weight(1.2f)
                    .clickable { onGoLiveClick() }
                    .testTag("nav_go_live"),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = Color.Transparent,
                    shadowElevation = 6.dp
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(22.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(SanaPinkPrimary, SanaPurpleSecondary)
                                )
                            )
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Videocam,
                                contentDescription = "Go Live",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Live",
                                color = Color.White,
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            )
                        }
                    }
                }
            }

            // Messages
            val isMessages = currentScreen is Screen.Messages
            BottomNavItem(
                icon = if (isMessages) Icons.Filled.ChatBubble else Icons.Outlined.ChatBubbleOutline,
                label = "Messages",
                isSelected = isMessages,
                onClick = { onNavigate(Screen.Messages) },
                modifier = Modifier.weight(1f),
                testTag = "nav_messages"
            )

            // Profile
            val isProfile = currentScreen is Screen.Profile
            BottomNavItem(
                icon = if (isProfile) Icons.Filled.Person else Icons.Outlined.Person,
                label = "Profile",
                isSelected = isProfile,
                onClick = { onNavigate(Screen.Profile) },
                modifier = Modifier.weight(1f),
                testTag = "nav_profile"
            )
        }
    }
}

@Composable
private fun BottomNavItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(vertical = 4.dp)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isSelected) SanaPinkPrimary else Color(0xFF9E8B9E),
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                color = if (isSelected) SanaPinkPrimary else Color(0xFF9E8B9E),
                fontSize = 10.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
            )
        }
    }
}
