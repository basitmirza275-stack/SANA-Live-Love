package com.example

import com.example.data.model.GiftType
import com.example.data.model.ReportStatus
import com.example.data.repository.SanaRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class SanaRepositoryTest {

    @Test
    fun testAllVirtualGiftsAreFree() {
        val allGifts = GiftType.values()
        assertEquals(15, allGifts.size)
        allGifts.forEach { gift ->
            assertTrue("Gift ${gift.giftName} must be 100% free", gift.isFree)
            assertEquals("Gift ${gift.giftName} purchase cost must be 0 coins", 0, gift.purchaseCostCoins)
        }

        // Specifically test huge gifts with large displayed values are free
        assertTrue(GiftType.LUXURY_CAR.isFree)
        assertEquals(0, GiftType.LUXURY_CAR.purchaseCostCoins)
        assertTrue(GiftType.ROYAL_INFINITY.isFree)
        assertEquals(0, GiftType.ROYAL_INFINITY.purchaseCostCoins)
    }

    @Test
    fun testSendFreeGiftAddsEventAndIncrementsLikes() = runTest {
        val testScope = TestScope()
        val repo = SanaRepository(testScope)

        val stream = repo.liveStreams.value.first()
        val initialLikes = stream.likesCount

        val event = repo.sendFreeGift(stream.id, GiftType.ROSE)
        assertNotNull(event)
        assertEquals(GiftType.ROSE, event.giftType)

        val updatedStream = repo.liveStreams.value.first { it.id == stream.id }
        assertTrue(updatedStream.likesCount > initialLikes)

        // Verify comment stream contains the celebratory announcement
        val comments = repo.streamComments.value[stream.id] ?: emptyList()
        assertTrue(comments.any { it.isGiftMessage && it.giftType == GiftType.ROSE })
    }

    @Test
    fun testMultiGuestStageJoinAndLeave() = runTest {
        val testScope = TestScope()
        val repo = SanaRepository(testScope)
        val stream = repo.liveStreams.value.first()

        repo.joinAsGuest(stream.id)
        var updatedStream = repo.liveStreams.value.first { it.id == stream.id }
        assertTrue(updatedStream.guests.any { it.id == "user_me" })

        repo.leaveGuestStage(stream.id)
        updatedStream = repo.liveStreams.value.first { it.id == stream.id }
        assertFalse(updatedStream.guests.any { it.id == "user_me" })
    }

    @Test
    fun testSafetyReportAndModeration() = runTest {
        val testScope = TestScope()
        val repo = SanaRepository(testScope)

        repo.submitReport(
            reportedUserId = "user_kenji",
            reportedUserName = "Kenji",
            streamId = "stream_kenji",
            reason = "Spam",
            details = "Posting spam links"
        )

        val reports = repo.reports.value
        val report = reports.firstOrNull { it.reportedUserId == "user_kenji" }
        assertNotNull(report)
        assertEquals(ReportStatus.PENDING, report?.status)

        // Admin resolves report and suspends account
        repo.resolveReport(report!!.id, suspendUser = true)
        val resolvedReport = repo.reports.value.first { it.id == report.id }
        assertEquals(ReportStatus.RESOLVED, resolvedReport.status)

        val kenjiUser = repo.allUsers.value.first { it.id == "user_kenji" }
        assertTrue(kenjiUser.isBlocked)
    }

    @Test
    fun testToggleFollowUser() = runTest {
        val testScope = TestScope()
        val repo = SanaRepository(testScope)

        assertFalse(repo.isFollowing("user_chloe"))
        repo.toggleFollow("user_chloe")
        assertTrue(repo.isFollowing("user_chloe"))
        repo.toggleFollow("user_chloe")
        assertFalse(repo.isFollowing("user_chloe"))
    }
}
